"use client";

import { useState, useEffect } from "react";
import { Check, Shield, Zap, Lock, Clock, Star, AlertCircle } from "lucide-react";
import Button from "../components/ui/button";
import Card from "../components/ui/card";
import CardContent from "../components/ui/card-content";

export default function Page() {
  const [timeLeft, setTimeLeft] = useState({ hours: 23, minutes: 59, seconds: 59 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { hours: prev.hours, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <main className="bg-black min-h-screen">
      <Hero />
      <WhyTrustUs />
      <Pricing />
      <LimitedOffer timeLeft={timeLeft} />
      <Testimonials />
      <Safety />
      <FinalCTA />
    </main>
  );
}

/* ------- Hero ------- */
function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-red-950/20 via-black to-black"/>
      <div className="relative z-10 max-w-4xl px-6 text-center space-y-6">
        <h1 className="text-5xl md:text-7xl font-bold">🔥 Premium Video Bundle 🔥</h1>
        <p className="text-lg text-gray-300">Instant access to <span className="text-red-500 font-semibold">500+ videos</span> — lifetime updates.</p>

        <div className="flex gap-4 justify-center mt-6">
          <Button className="bg-gradient-to-r from-red-600 to-red-700 px-8 py-4 text-lg">🎬 Get Instant Access</Button>
        </div>
      </div>
    </section>
  );
}

/* ------- WhyTrustUs ------- */
function WhyTrustUs() {
  const items = [
    { icon: "📚", text: "500+ Videos Library" },
    { icon: "⚡", text: "Instant Access" },
    { icon: "🔒", text: "100% Private" },
    { icon: "💰", text: "One-time Payment" },
    { icon: "💬", text: "24/7 Support" }
  ];
  return (
    <section className="py-16 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-4xl font-bold mb-8">Why Trust Us? 🤝</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
          {items.map((it,i) => (
            <div key={i} className="flex flex-col items-center gap-3">
              <div className="w-20 h-20 bg-gray-900 rounded-full flex items-center justify-center text-3xl">{it.icon}</div>
              <div className="text-white text-sm font-medium">{it.text}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------- Pricing (3 cards) ------- */
function Pricing() {
  const plans = [
    { name: "Premium", price: "₹299", color: "from-orange-500 to-orange-600", url: "https://your-shopify-checkout-link-1" },
    { name: "Ultimate", price: "₹399", color: "from-yellow-500 to-yellow-600", url: "https://your-shopify-checkout-link-2", popular: true },
    { name: "Exclusive", price: "₹499", color: "from-blue-500 to-blue-600", url: "https://your-shopify-checkout-link-3" }
  ];
  return (
    <section className="py-16 px-4">
      <div className="max-w-7xl mx-auto text-center">
        <h2 className="text-4xl font-bold mb-4">Choose Your Package 📦</h2>
        <p className="text-gray-400 mb-8">Select the perfect bundle for you</p>
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((p,i) => (
            <Card key={i} className={p.popular ? "border-yellow-500/40 scale-100" : "border-gray-800"}>
              <CardContent>
                <div className="text-5xl mb-4 text-center">🎬</div>
                <h3 className="text-2xl font-bold text-white text-center">{p.name}</h3>
                <div className="text-center my-4"><span className="text-4xl font-bold">{p.price}</span><span className="text-gray-400 ml-2">one-time</span></div>
                <div className="space-y-2 mb-6 text-left">
                  <div className="flex items-start gap-3"><Check className="w-4 h-4 text-green-500 mt-1" /><span className="text-gray-300">Premium videos</span></div>
                  <div className="flex items-start gap-3"><Check className="w-4 h-4 text-green-500 mt-1" /><span className="text-gray-300">Lifetime access</span></div>
                </div>
                <Button onClick={() => window.location.href = p.url} className={`w-full bg-gradient-to-r ${p.color} text-white py-3 font-semibold rounded-lg`}>
                  Get {p.name} - {p.price}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------- LimitedOffer ------- */
function LimitedOffer({ timeLeft }) {
  return (
    <section className="py-8 px-4">
      <div className="max-w-4xl mx-auto bg-gradient-to-r from-red-600 to-red-700 rounded-xl p-6 text-center">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3"><AlertCircle className="w-6 h-6" /><div className="text-white font-bold">⚠️ Limited Time Offer</div></div>
          <div className="flex gap-3">
            <div className="bg-black/30 rounded p-2 min-w-[64px] text-center">
              <div className="text-lg font-bold">{String(timeLeft.hours).padStart(2,'0')}</div><div className="text-xs text-gray-300">Hours</div>
            </div>
            <div className="bg-black/30 rounded p-2 min-w-[64px] text-center">
              <div className="text-lg font-bold">{String(timeLeft.minutes).padStart(2,'0')}</div><div className="text-xs text-gray-300">Minutes</div>
            </div>
            <div className="bg-black/30 rounded p-2 min-w-[64px] text-center">
              <div className="text-lg font-bold">{String(timeLeft.seconds).padStart(2,'0')}</div><div className="text-xs text-gray-300">Seconds</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------- Testimonials ------- */
function Testimonials() {
  const list = [
    { name: "Amit S.", city: "Delhi", text: "Amazing quality!" },
    { name: "Priya M.", city: "Bangalore", text: "Best decision ever!" },
    { name: "Vikram R.", city: "Pune", text: "Outstanding service!" },
    { name: "Rahul K.", city: "Mumbai", text: "Exceeded my expectations!" }
  ];
  return (
    <section className="py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-8">What Our Customers Say</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {list.map((t,i) => (
            <Card key={i}><CardContent>
              <div className="mb-3">{[...Array(5)].map((_,i)=>(<Star key={i} className="w-4 h-4 inline-block text-yellow-400" />))}</div>
              <p className="text-gray-300 mb-3 text-sm">{t.text}</p>
              <div className="text-white font-semibold">{t.name}</div>
              <div className="text-gray-400 text-xs">{t.city}</div>
            </CardContent></Card>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------- Safety ------- */
function Safety() {
  return (
    <section className="py-12 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
          <div><div className="p-4 bg-gray-900 rounded-full inline-block"><Shield className="w-6 h-6" /></div><div className="text-white mt-2">Secure Payment</div></div>
          <div><div className="p-4 bg-gray-900 rounded-full inline-block"><Zap className="w-6 h-6" /></div><div className="text-white mt-2">Instant Delivery</div></div>
          <div><div className="p-4 bg-gray-900 rounded-full inline-block"><Lock className="w-6 h-6" /></div><div className="text-white mt-2">18+ Content</div></div>
          <div><div className="p-4 bg-gray-900 rounded-full inline-block"><Shield className="w-6 h-6" /></div><div className="text-white mt-2">Data Protected</div></div>
        </div>
        <Button className="bg-gradient-to-r from-green-600 to-green-700 px-6 py-3">Need Help? Chat with Support →</Button>
      </div>
    </section>
  );
}

/* ------- Final CTA ------- */
function FinalCTA() {
  const finalPlans = [
    { name: "Premium", price: "₹299", url: "https://your-shopify-checkout-link-1" },
    { name: "Ultimate", price: "₹399", url: "https://your-shopify-checkout-link-2" },
    { name: "Exclusive", price: "₹499", url: "https://your-shopify-checkout-link-3" }
  ];
  return (
    <section className="py-20 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold mb-6">Ready to Make Your Night Special? 🌙</h2>
        <p className="text-gray-300 mb-8">Join thousands of satisfied customers today!</p>
        <div className="flex flex-col md:flex-row gap-4 justify-center">
          {finalPlans.map((p,i) => (
            <Button key={i} onClick={() => (window.location.href = p.url)} className="px-8 py-4 rounded-full bg-gradient-to-r from-orange-500 to-red-600">
              {p.name} - {p.price}
            </Button>
          ))}
        </div>
        <p className="text-gray-400 mt-6 text-sm">🔒 Secure Payment • ⚡ Instant Access • 🔄 Lifetime Updates</p>
      </div>
    </section>
  );
}
