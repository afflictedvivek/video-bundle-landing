import './globals.css';

export const metadata = {
  title: 'Video Bundle — Landing',
  description: 'Premium video bundle landing page'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  )
}
