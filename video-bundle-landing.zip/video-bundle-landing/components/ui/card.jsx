export default function Card({ children, className = "" }) {
  return <div className={`rounded-2xl border border-gray-800 overflow-hidden ${className}`}>{children}</div>;
}
