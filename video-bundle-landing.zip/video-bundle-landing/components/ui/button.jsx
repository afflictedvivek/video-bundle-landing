export default function Button({ children, className = "", onClick, size }) {
  return (
    <button
      onClick={onClick}
      className={`${className} inline-flex items-center justify-center rounded-md transition`}
    >
      {children}
    </button>
  );
}
